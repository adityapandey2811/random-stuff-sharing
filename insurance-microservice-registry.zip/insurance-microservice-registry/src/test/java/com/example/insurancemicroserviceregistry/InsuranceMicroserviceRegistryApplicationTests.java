package com.example.insurancemicroserviceregistry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InsuranceMicroserviceRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}

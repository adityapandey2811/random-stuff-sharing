# Insurance-Project-Registry
Registry for insurance project microservices.
